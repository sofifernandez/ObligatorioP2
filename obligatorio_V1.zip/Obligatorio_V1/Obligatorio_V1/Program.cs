﻿using Dominio;
using System;

namespace Obligatorio_V1
{
    class Program
    {
        static Sistema unS = Sistema.Instancia;
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
